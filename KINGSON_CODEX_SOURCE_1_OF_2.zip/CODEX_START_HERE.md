# KINGSON ENGINEERING — CODEX START HERE

**This task is for the EXISTING deployed Kingson website, NOT a new website.**

Repository: `kudzi03/KingsonEngineering`.

## What to do

1. Confirm BOTH ZIP files are present in the repository root:
   - `KINGSON_CODEX_SOURCE_1_OF_2.zip`
   - `KINGSON_CODEX_SOURCE_2_OF_2.zip`
2. Unzip BOTH into the SAME scratch location (for example `/tmp/kingson-redesign-input/`). `CODEX_TASK.md` and `assets/` and `reference/` will be assembled together. Do not extract over and replace website source files by accident.
3. Read `CODEX_TASK.md` FULLY. Watch `reference/user-design-reference.mp4` FULLY; use this exact reference to guide the redesign.
4. Inspect ALL real Kingson user-supplied footage and two photographs under `assets/`. They are the actual content to use; the reference is a competitor/example and must never be published as a Kingson project.
5. Carry out the brief in the CURRENT site codebase, improve footage where feasible, and present desktop/mobile previews for approval BEFORE any production deploy.
6. No unrelated design platform, no new site, no DNS/domain changes, no production deployment without the user approving.

## Upload context

Github's web uploader caps each file at 25 MB. To preserve the FULL-LENGTH ORIGINAL user-supplied MP4s rather than degrading them to squeeze into one file, the source set is split into two ordinary ZIP files under 25 MB each. Both are required. They are NOT split-volume ZIP segments: each is independently extractable with ordinary unzip/zipfile tools.

## What is in each ZIP

- ZIP 1: this instruction file, `CODEX_TASK.md`, `assets/workshop-walkthrough.mp4`, `assets/roof-structure-project-a.mp4`
- ZIP 2: `assets/roof-structure-project-b.mp4`, two `assets/*.jpeg` photographs, `reference/user-design-reference.mp4` (exact reference), and `reference/reference-contact-sheet.jpg`

## Important media rule

The videos are 512px wide, because that is how they were shared. Preserve these full-resolution originals in a work folder; test real enhancement separately. Do not claim exporting at a larger resolution increases original detail. Do not publish screen UI overlays or the reference film on the Kingson website.
