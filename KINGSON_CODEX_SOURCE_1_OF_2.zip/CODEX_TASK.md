# Codex execution brief — Kingson Engineering live-site redesign

## Mission and context

**You are editing an existing, deployed website, NOT starting a new project.**

- Repository: `https://github.com/kudzi03/KingsonEngineering` (inspect the current branch/HEAD rather than assuming an old commit is current).
- Existing deployed Vercel site: `https://kingson-engineering.vercel.app/`. The current official-domain status is not independently confirmed. Do not assume DNS setup is complete and do not change DNS as part of the redesign.
- The site has historically been plain HTML, CSS, JS, with Vercel deployment. Preserve the existing stack unless a specific technical need justifies a change.
- User is redesigning an already-live website for a real Harare engineering business. **Do not touch DNS/domain setup, break company mail, or publish to production without first showing a preview and getting approval.**
- The user previously rejected weak/empty generic website directions. Avoid introducing unrelated stock visuals, invented company claims, beige blank hero compositions, AI-looking CGI, unnecessary cards, imaginary project names, mock data or fake credentials.

## Attached source materials in this handoff

- `reference/user-design-reference.mp4`: **this is the user's visual reference**, a mobile video of a construction website displayed on a laptop. Inspect it before changing code. It has an immersive house-photo hero with restrained overlaid identity, project showcases, client/testimonial presentation and contact section. Study its *layout, confident photo scale, clean navigation, compositional hierarchy, visual momentum and transitions*, not the Instagram captions or someone else's company styling. The reference is **not** footage of Kingson, so do not publish it as Kingson material.
- `reference/reference-contact-sheet.jpg`: sampled reference timestamps (~0, 3, 6, 9, 12, 15 seconds); use video itself for motion.
- `assets/workshop-walkthrough.mp4`: user-recorded Kingson workshop, equipment, premises and exterior. 512x910 @ 30fps, 12 seconds, vertical.
- `assets/roof-structure-project-a.mp4`: roofing / large truss and framework project, 512x808 @ 30fps, 25.4 seconds, vertical. User-supplied screen recording.
- `assets/roof-structure-project-b.mp4`: another roofing view, 512x1112 @ 30fps, ~16.6 seconds, vertical. Screen-recording overlays/phone UI are visible and must be removed/cropped/avoided where feasible.
- `assets/architectural-glass-exterior.jpeg`, `assets/architectural-atrium-interior.jpeg`: user supplied project photographs. Use as-is unless restrained crop/optimization helps.
- No experimental processed preview is included, to preserve the original video quality within GitHub browser upload limits. Test enhancement on the project clips yourself, without replacing or overwriting the source clips.

## Required result

A **premium, visually commanding redesign of Kingson's existing homepage**, with a **full-viewport, image-led / video-led hero** and real work prominent throughout, informed by the actual reference video rather than generic web-design tropes.

1. Start by auditing the running site, all homepage markup/styles/scripts, current image assets, service navigation, contact/WhatsApp/form pathways, accessibility, SEO and responsive behavior. Preserve correct business facts and lead capture. Take *before* screenshots at desktop (1440x900) and mobile (390x844).
2. Watch the full attached reference video and list 5-8 concrete observations, including what makes the opening visually arresting, navigation treatment, typography placement, project gallery rhythm and transitions. **Translate these qualities to real industrial work**; do not imitate the recorded Instagram overlay or construction business on the laptop.
3. Use the strongest Kingson project visuals to create a full-screen, cinematic hero. The desired emotional subject is **scale, structural engineering and completed results**; prioritize the expansive truss/roof project. The user's instruction is a *full video hero* similar in immersive effect to the reference. Try with the supplied video clips on desktop and mobile, but evaluate whether pillarboxing/upscale/crop damages clarity. If video visibly fails at desktop scale, use a high-quality still or a well-composed mixed sequence as desktop fallback and make vertical motion more prominent on mobile. **Do not force an ugly pixelated video just to satisfy literal video usage.** Provide both treatments for review when possible.
4. Keep headline and conversion actions readable: one short credible core statement for structural fabrication / roofing / steelwork and prominent **Request a Quote** plus **Our Projects**, positioned so the hero visual stays dominant. Use existing verified copy, actual brand styles/logo and real service capabilities, not made-up specs. Navigation must remain usable atop moving background.
5. Carry reference-inspired polish into project presentation: large media, little clutter, restrained type, consistent pacing, confident scale, natural color of real materials, strong mobile layouts. Include photo work from the two supplied architectural images in appropriate existing-project places. Preserve existing service pages and contact information.
6. Use the user-supplied media. Never replace it with stock image searches or synthetic industrial footage unless user explicitly asks. Preserve media provenance. Never publish the reference reel as a Kingson asset.
7. Try video improvement safely: inspect native resolution, contrast, grain, clipping and overlays; trim to the most convincing shots; crop any screen-recording UI where practical; apply *subtle* denoise/sharpen/stabilization, correct slight color casts as needed. Investigate genuine AI super-resolution only if an available tool/model exists and test outputs side by side for invented detail, warping and oversharpening. **Simply rescaling 512px to 1080/1920px is not real recovered resolution.** Favor faithful footage over fake looking enhancement. Export efficient MP4/H.264 and/or WebM/VP9/AV1 variants appropriate to playback constraints; make a crisp poster. Keep originals untouched. Don't amplify music/audios from social posts; hero background should be muted.
8. Video must be silent/muted, autoplay inline where allowed, loop smoothly, include a high-quality poster fallback and correctly handle `prefers-reduced-motion`, mobile data/performance and users without autoplay. No forced waiting to interact; avoid huge LCP/CLS and blocked form inputs. Ensure visible focus, readable overlay and tap targets.
9. Treat the visible reference as a *quality benchmark*, not an excuse to clone a competitor or to add arbitrary glassmorphism, gradients, glow, HUD graphics, excessive scroll-lock or fake stats. Prior Kingson creative feedback rejected empty beige sections and detached photographs; actual images should occupy the visual field.
10. **Make actual code changes in the existing repo**, test in a running preview, take screenshots of final desktop/mobile, and compare them to the reference and initial site. Report source video resolution, what quality work was performed, the limitations remaining, a short performance check and any issue with contact form delivery.
11. Make changes on a safe feature branch / preview deployment. **Do not silently push changes live.** Present preview link and screenshots for user approval before merging/deploying to production.

## Coding and QA priorities

- Preserve existing static stack and business functionality; no unnecessary React rewrite or new product architecture.
- Audit real on-page facts instead of fabricating capabilities or customer endorsements.
- Verify `www` and root domain already point to production before making any assumption; do not edit domain DNS. This is a design/media task.
- Treat the screen-captured content as project material only where approved by user; remove foreign UI/comment overlays where feasible; keep project descriptions factual.
- Avoid heavy cinematic effects for their own sake. Reference quality comes mainly from hierarchy and full-bleed visual content.
- Screenshot test: desktop 1440x900 and 1920x1080, mobile 390x844; nav, form, WhatsApp, accessibility, reduced motion, fallback poster, no horizontal overflow and no intrusive overlays.
- Acceptance criterion: the first two seconds should unmistakably show an impressive real Kingson engineering project; type and navigation should remain instantly legible; no unfinished/pixelated feel on desktop; reference-inspired layout is obvious; all services and enquiries still work.

## User's core intent

> The website is already live. We are **redesigning it in Codex**, not choosing a new builder or repeating domain setup. Use the *exact video reference I supplied* and my actual company project clips/images. Make the visual quality substantially better. Enhance the clips where genuinely possible, then implement and show me the preview.
