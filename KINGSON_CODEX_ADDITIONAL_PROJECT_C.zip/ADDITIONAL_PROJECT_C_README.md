# KINGSON ENGINEERING — ADDITIONAL PROJECT FOOTAGE (C)

This supplemental file adds a NEW, actual Kingson project video to the EXISTING redesign handoff.

## Extracted asset

- `assets/roof-structure-project-c-ORIGINAL.mp4` — the **original file bytes**, unedited, no recompression, full **28.27-second** duration.
- `assets/roof-structure-project-c-contact-sheet.jpg` — eight inspection frames, provided only as a reviewing convenience.

Video information: **512 × 910 portrait**, 30fps, H.264 with AAC audio, **17,264,390 bytes**. Source SHA-256: `c3d883175019a688e8912c67991e10127f8f6f361c47b59fcfee9d4513a17a53`.

## What the footage shows

Interior upward-looking and lateral views of a large steel-framed roof / industrial structure, including structural members, cladding and exposed sections. This is a **third Kingson-supplied project clip**, not a replacement for roofing project A or B. Do not invent location, client, completion date, dimensions, load ratings or the project's official name. Confirm any project-specific public claims before publishing.

## How Codex must use this footage

1. Unpack this ZIP to the SAME TEMPORARY INPUT DIRECTORY used for `KINGSON_CODEX_SOURCE_1_OF_2.zip` and `KINGSON_CODEX_SOURCE_2_OF_2.zip`. Don't unpack over project source or web root.
2. Read the existing `CODEX_START_HERE.md` and `CODEX_TASK.md` from archive 1 as the authoritative redesign brief. Treat this README as an **additional asset note**, not a replacement for those instructions.
3. Fully inspect video C as well as workshop video and roofing A/B clips. Compare all for the highest-impact hero opening and project-gallery sequence, using the user's original `reference/user-design-reference.mp4` as the visual aesthetic benchmark.
4. Preserve the full original file in staging; when optimizing the site, generate separate derivatives. Consider shot selection, stabilizing if warranted, carefully cropping problematic edges, and gentle denoising/sharpening. If AI super-resolution is genuinely available, compare it against originals at real display sizes and reject hallucinated/waxy/warped steel detail. Scaling does not restore lost detail.
5. The source video is vertical and only 512px wide. Test full-width desktop treatment for grain/crop/letterboxing and use an attractive fallback if needed. Keep crisp poster, muted inline loop, reduced-motion accessible still, mobile optimization and efficient loading. Don't use audio in autoplay backgrounds.
6. Preserve existing Kingson repository, operational contact channels and site functionality. Make changes on a safe feature branch/preview; never deploy to live Vercel without the user's explicit approval.

## Intended repo filename

`KINGSON_CODEX_ADDITIONAL_PROJECT_C.zip` alongside the three already uploaded handoff files at repository root. This ZIP stays smaller than GitHub's 25 MB browser-upload limit, and it contains the unchanged source video.
